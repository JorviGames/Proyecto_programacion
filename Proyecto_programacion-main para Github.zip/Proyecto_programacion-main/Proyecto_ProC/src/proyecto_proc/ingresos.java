/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_proc;

/**
 *
 * @author laicy
 */
public class ingresos {
    //registro de la plata que ingresa por día
}
